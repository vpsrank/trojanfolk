# Linux Smoke Test

## Dependencies

- coreutils
- openssl
- python3
- curl

## Usage

```
./basic.sh /path/to/trojan
./fake-client.sh /path/to/trojan
```
